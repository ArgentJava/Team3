/*  Alyssa Trevino
    24FA-CS211
    12/8/24
    Friend.cpp
*/
#include <fstream>
#include "Friend.hpp"
#include <iostream>
#include <string>
using namespace std;

class Serializable {
private:
    string name;
    string number;
    int score;

public:
    Serializable(){};
    // Constructor to initialize the data members
    Serializable(const string& name, string number, int score)
        : name(name)
        , number(number)
        , score(score)
    {
    }
    // Getter methods for the class
    string getName() const { return name; }
    string getNumber() const { return number; }
    int getScore() const { return score; }

    //  Function for Serialization
    void serialize(const string& filename)
    {
        ofstream file(filename, ios::binary);
        if (!file.is_open()) {
            cerr
                << "Error: Failed to open file for writing."
                << endl;
            return;
        }
        file.write(reinterpret_cast<const char*>(this),
                   sizeof(*this));
        file.close();
        cout << "Object serialized successfully." << endl;
    }

    //  Function for Deserialization
    static Serializable deserialize(const string& filename)
    {
        Serializable obj("", "", 0);
        ifstream file(filename, ios::binary);
        if (!file.is_open()) {
            cerr
                << "Error: Failed to open file for reading."
                << endl;
            return obj;
        }
        file.read(reinterpret_cast<char*>(&obj),
                  sizeof(obj));
        file.close();
        cout << "Object deserialized successfully." << endl;
        return obj;
    }
};
    
int main(){
    Friend F1("Ruben", "5598246140", 99);
    //cout << F1.getName() << "\t" << 
    //F1.getPhNum() << "\t" <<
    //F1.getScore() << "\t" <<
    //F1.incScore(5) << "\t" <<
    //F1.decScore(3) << "\t" <<
    //F1.altScore() << endl;
    //cout << F1.displayFriend();
    
    Serializable original(F1.getName(), F1.getPhNum(), F1.getScore());
    original.serialize("data.bin");

    // Deserialize the object
    Serializable restored
        = Serializable::deserialize("data.bin");

    // Test the  deserialized object
    cout << "Deserialized Object:\n";
    cout << "Name: " << restored.getName() << endl;
    cout << "Age: " << restored.getNumber() << endl;
    cout << "Score: " << restored.getScore() << endl;
  
    return 0;
}